URBAN MEMORY - SVG City Map Pack

Includes 6 premium architectural city map styles:
  BLUEPRINT — Classic cyanotype aesthetic
  CHARCOAL — High-contrast monochrome
  URBAN_GRAIN — Textured urban fabric
  NOLLI — Figure-ground mapping
  TERRA — Earth tones
  SEPIA — Vintage cartography

Each map is generated from real OpenStreetMap building footprint data.

Format: SVG (Scalable Vector Graphics)
Resolution: Print-ready, infinitely scalable
License: Commercial use allowed for physical products (up to 500 units)
Created by Studio Homotomo

www.urbanmemory.com | studio@urbanmemory.com
